#ifndef RADIO_WE_H
#define RADIO_WE_H

#if ARDUINO < 100
#include <WProgram.h>
#else
#include <Arduino.h>
#endif

#define MAX_BETWEEN_SIGNALS_TIME 150
#define THRESHOLD 300   


class Radio_WE{
	public:
		Radio_WE(int, int); 
		Radio_WE(int, int, unsigned long, unsigned long);
		void Init();
		void setRxPin(int); 
		void setTxPin(int);	   //Reset Pin des Arduino
		void setMaxListenTime(unsigned long);
		void setNoSignalReturnVal(unsigned long);
		void sendNumber(unsigned long); 
		unsigned long receiveNumber();
				
		
	private:
		int rxPin, txPin;
		unsigned long maxListenTime = 60000;
		unsigned long noSignalReturnVal = 0;
		void numberToDigits(unsigned long&, byte*, byte&); 
		void sendDigit(byte);
};

#endif

