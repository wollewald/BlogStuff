#include "Radio_WE.h"

Radio_WE::Radio_WE(int rx, int tx) 
	: rxPin(rx), txPin(tx){}
	
Radio_WE::Radio_WE(int rx, int tx, unsigned long mlt, unsigned long nsrv) 
	: rxPin(rx), txPin(tx), maxListenTime(mlt), noSignalReturnVal(nsrv){}

void Radio_WE::Init(){
	pinMode(txPin, OUTPUT); 
};

void Radio_WE::setRxPin(int rx){
	rxPin = rx;
}

void Radio_WE::setTxPin(int tx){
	txPin = tx;
}

void Radio_WE::setMaxListenTime(unsigned long mlt){
	maxListenTime = mlt;
}

void Radio_WE::setNoSignalReturnVal(unsigned long nsrv){
	noSignalReturnVal = nsrv;
}

void Radio_WE::sendNumber(unsigned long number){
	byte digits[6] = {0,0,0,0,0,0};  //Das Programm kann 6-stellige Zahlen übergeben
	byte arrLength;
	numberToDigits(number, digits, arrLength);
	sendDigit(2);
	sendDigit(1);
	sendDigit(4);
	for(int i = 0; i<arrLength; i++){
		sendDigit(digits[i]);
	}
}

unsigned long Radio_WE::receiveNumber(){
	int maxDigit=-1;
	unsigned long number=0;
    int digit[9];
	unsigned long listenBeginTime;
	unsigned long lastSignalTime = 0;
	for(int i=0; i<3; i++) digit[i]=0;
	unsigned int counter;  //Zähler für 50 Mikrosekundeneinheiten; 50 Mikrosekunden ist die Auflösung
	bool firstSignal = true;
	bool messageCompleted = false;
	listenBeginTime=millis();
	do{
		counter = 0;
		while((analogRead(rxPin)<=THRESHOLD)&&((millis()-listenBeginTime) < maxListenTime)){
			if(!firstSignal && ((millis()-lastSignalTime) > MAX_BETWEEN_SIGNALS_TIME)){
				messageCompleted = true;
				break;
			}
		}
		while((analogRead(rxPin)>THRESHOLD)&&((millis()-listenBeginTime) < maxListenTime)){  // Messe die Funksignallänge
			delayMicroseconds(50);
			counter++;
		}
		if(counter>9){ // nur wenn, dass Funksignal eine Mindestlänge hat, ist es kein Störsignal
			firstSignal = false; 
			lastSignalTime=millis();
			maxDigit++;
			digit[maxDigit]=((int)round(counter/12.5));
		}
		
	}while(!messageCompleted && ((millis()-listenBeginTime) < maxListenTime));
	if((digit[0]==3&&digit[1]==2&&digit[2]==5)&&(messageCompleted==true)){
		unsigned long pot=1;
		for(int i=3; i<=maxDigit; i++){
		number += (digit[i]-1)*pot;
		pot = pot*10;
		}
		return number;
	}
	else return noSignalReturnVal;
}

void Radio_WE::numberToDigits(unsigned long &nr, byte *arr, byte &len){  // *arr = &arr[0]
	len = 0;
    while(nr>0){
		arr[len]=nr%10;
		nr=nr/10;
        if(nr >= 0) len++;
	}
}

void Radio_WE::sendDigit(byte dig){
	digitalWrite(txPin, HIGH);
	delay((dig+1)*2);
	digitalWrite(txPin, LOW);
	delay(5);
}


